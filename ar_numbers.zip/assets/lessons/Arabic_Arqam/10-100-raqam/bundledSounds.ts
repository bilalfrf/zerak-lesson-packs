import type { AVPlaybackSource } from "expo-av";

const SOUNDS: Record<number, AVPlaybackSource> = {
  10: require("./10-100-arqam10.mp3"),
  20: require("./10-100-arqam20.mp3"),
  30: require("./10-100-arqam30.mp3"),
  40: require("./10-100-arqam40.mp3"),
  50: require("./10-100-arqam50.mp3"),
  60: require("./10-100-arqam60.mp3"),
  70: require("./10-100-arqam70.mp3"),
  80: require("./10-100-arqam80.mp3"),
  90: require("./10-100-arqam90.mp3"),
  100: require("./10-100-arqam100.mp3"),
};

export function getBundledTensSound(value: number): AVPlaybackSource | null {
  return SOUNDS[value] ?? null;
}
