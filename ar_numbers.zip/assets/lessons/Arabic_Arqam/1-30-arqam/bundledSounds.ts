import type { AVPlaybackSource } from "expo-av";

const SOUNDS: Record<number, AVPlaybackSource> = {
  1: require("./1-10/arqam1.mp3"),
  2: require("./1-10/arqam2.mp3"),
  3: require("./1-10/arqam3.mp3"),
  4: require("./1-10/arqam4.mp3"),
  5: require("./1-10/arqam5.mp3"),
  6: require("./1-10/arqam6.mp3"),
  7: require("./1-10/arqam7.mp3"),
  8: require("./1-10/arqam8.mp3"),
  9: require("./1-10/arqam9.mp3"),
  10: require("./1-10/arqam10.mp3"),
  11: require("./11-20/arqam11.mp3"),
  12: require("./11-20/arqam12.mp3"),
  13: require("./11-20/arqam13.mp3"),
  14: require("./11-20/arqam14.mp3"),
  15: require("./11-20/arqam15.mp3"),
  16: require("./11-20/arqam16.mp3"),
  17: require("./11-20/arqam17.mp3"),
  18: require("./11-20/arqam18.mp3"),
  19: require("./11-20/arqam19.mp3"),
  20: require("./11-20/arqam20.mp3"),
  21: require("./21-30/arqam21.mp3"),
  22: require("./21-30/arqam22.mp3"),
  23: require("./21-30/arqam23.mp3"),
  24: require("./21-30/arqam24.mp3"),
  25: require("./21-30/arqam25.mp3"),
  26: require("./21-30/arqam26.mp3"),
  27: require("./21-30/arqam27.mp3"),
  28: require("./21-30/arqam28.mp3"),
  29: require("./21-30/arqam29.mp3"),
  30: require("./21-30/arqam30.mp3"),
};

export function getBundledArqam1to30(value: number): AVPlaybackSource | null {
  if (value >= 1 && value <= 30) return SOUNDS[value] ?? null;
  return null;
}
